

```python
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
plt.style.use('ggplot')
from scipy import stats
%matplotlib inline
from sklearn import linear_model as lm
from sklearn import datasets
import statsmodels.api as sm
```


```python
reading_8 = pd.read_csv('class2011_reading_8_division.csv').drop('Unnamed: 0',axis=1)
reading_8_agg = reading_8[reading_8.GENDER.isnull()&reading_8.FEDERAL_RACE_CODE.isnull()&reading_8.DISABILITY_FLAG.isnull()&reading_8.LEP_FLAG.isnull()&reading_8.DISADVANTAGED_FLAG.isnull()]
reading_8_agg.index = reading_8_agg[['DIV_NUM','DIV_NAME']]
reading_8_agg = reading_8_agg.drop(['DIV_NUM','DIV_NAME','GENDER','FEDERAL_RACE_CODE','DISABILITY_FLAG','LEP_FLAG','DISADVANTAGED_FLAG'],axis=1)
reading_8_agg.AVG_SOL_SCALE_SCORE.hist(bins=20)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1f0ea933e80>




![png](output_1_1.png)



```python
writing_8 = pd.read_csv('class2011_writing_8_division.csv').drop('Unnamed: 0',axis=1)
writing_8_agg = writing_8[writing_8.GENDER.isnull()&writing_8.FEDERAL_RACE_CODE.isnull()&writing_8.DISABILITY_FLAG.isnull()&writing_8.LEP_FLAG.isnull()&writing_8.DISADVANTAGED_FLAG.isnull()]
writing_8_agg.index = writing_8_agg[['DIV_NUM','DIV_NAME']]
writing_8_agg = writing_8_agg.drop(['DIV_NUM','DIV_NAME','GENDER','FEDERAL_RACE_CODE','DISABILITY_FLAG','LEP_FLAG','DISADVANTAGED_FLAG'],axis=1)
writing_8_agg.AVG_SOL_SCALE_SCORE.hist(bins=20)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1f0eaf02978>




![png](output_2_1.png)



```python
math_8 = pd.read_csv('class2011_math_8_division.csv').drop('Unnamed: 0',axis=1)
math_8_agg = math_8[math_8.GENDER.isnull()&math_8.FEDERAL_RACE_CODE.isnull()&math_8.DISABILITY_FLAG.isnull()&math_8.LEP_FLAG.isnull()&math_8.DISADVANTAGED_FLAG.isnull()]
math_8_agg.index = math_8_agg[['DIV_NUM','DIV_NAME']]
math_8_agg = math_8_agg.drop(['DIV_NUM','DIV_NAME','GENDER','FEDERAL_RACE_CODE','DISABILITY_FLAG','LEP_FLAG','DISADVANTAGED_FLAG'],axis=1)
math_8_agg.AVG_SOL_SCALE_SCORE.hist(bins=20)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1f0eaf89978>




![png](output_3_1.png)



```python
science_8 = pd.read_csv('class2011_science_8_division.csv').drop('Unnamed: 0',axis=1)
science_8_agg = science_8[science_8.GENDER.isnull()&science_8.FEDERAL_RACE_CODE.isnull()&science_8.DISABILITY_FLAG.isnull()&science_8.LEP_FLAG.isnull()&science_8.DISADVANTAGED_FLAG.isnull()]
science_8_agg.index = science_8_agg[['DIV_NUM','DIV_NAME']]
science_8_agg = science_8_agg.drop(['DIV_NUM','DIV_NAME','GENDER','FEDERAL_RACE_CODE','DISABILITY_FLAG','LEP_FLAG','DISADVANTAGED_FLAG'],axis=1)
science_8_agg.AVG_SOL_SCALE_SCORE.hist(bins=20)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1f0ecc47588>




![png](output_4_1.png)



```python
history_8 = pd.read_csv('class2011_history_8_division.csv').drop('Unnamed: 0',axis=1)
history_8_agg = history_8[history_8.GENDER.isnull()&history_8.FEDERAL_RACE_CODE.isnull()&history_8.DISABILITY_FLAG.isnull()&history_8.LEP_FLAG.isnull()&history_8.DISADVANTAGED_FLAG.isnull()]
history_8_agg.index = history_8_agg[['DIV_NUM','DIV_NAME']]
history_8_agg = history_8_agg.drop(['DIV_NUM','DIV_NAME','GENDER','FEDERAL_RACE_CODE','DISABILITY_FLAG','LEP_FLAG','DISADVANTAGED_FLAG'],axis=1)
history_8_agg.AVG_SOL_SCALE_SCORE.hist(bins=20)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1f0eccf9048>




![png](output_5_1.png)



```python
reading_8_agg = reading_8_agg.rename(columns={'AVG_SOL_SCALE_SCORE':'READING_SCORE','PASS_RATE':'READING_PASS_RATE'})
writing_8_agg = writing_8_agg.rename(columns={'AVG_SOL_SCALE_SCORE':'WRITING_SCORE','PASS_RATE':'WRITING_PASS_RATE'})
math_8_agg = math_8_agg.rename(columns={'AVG_SOL_SCALE_SCORE':'MATH_SCORE','PASS_RATE':'MATH_PASS_RATE'})
science_8_agg = science_8_agg.rename(columns={'AVG_SOL_SCALE_SCORE':'SCIENCE_SCORE','PASS_RATE':'SCIENCE_PASS_RATE'})
history_8_agg = history_8_agg.rename(columns={'AVG_SOL_SCALE_SCORE':'HISTORY_SCORE','PASS_RATE':'HISTORY_PASS_RATE'})
```


```python
sol_8_agg = pd.concat([reading_8_agg,writing_8_agg,math_8_agg,science_8_agg],axis=1).dropna()
sol_8_agg.drop(['READING_PASS_RATE','WRITING_PASS_RATE','MATH_PASS_RATE','SCIENCE_PASS_RATE'],axis=1).plot.hist(bins=20,stacked=True,xlim=(300,550))
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1f0ecd87f98>




![png](output_7_1.png)



```python
diploma = pd.read_csv('class2011_diploma_division.csv').drop('Unnamed: 0',axis=1)
diploma.DIPLOMA_CNT = round(diploma.DIPLOMA_CNT)
diploma.DROPOUT_CNT = round(diploma.DROPOUT_CNT)
diploma.DROPOUT_RATE = diploma.DROPOUT_CNT/diploma.COHORT_CNT*100
diploma_agg = diploma[diploma.GENDER.isnull()&diploma.FEDERAL_RACE_CODE.isnull()&diploma.DISABILITY_FLAG.isnull()&diploma.LEP_FLAG.isnull()&diploma.DISADVANTAGED_FLAG.isnull()]
diploma_agg.index = diploma_agg[['DIV_NUM','DIV_NAME']]
diploma_agg = diploma_agg.drop(['DIV_NUM','DIV_NAME','GENDER','FEDERAL_RACE_CODE','DISABILITY_FLAG','LEP_FLAG','DISADVANTAGED_FLAG'],axis=1)
diploma_agg.DIPLOMA_RATE.plot.hist(bins=20,xlim=(0,100))
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1f0ed8d1470>




![png](output_8_1.png)



```python
diploma_agg.DROPOUT_RATE.plot.hist(bins=10,xlim=(0,100))
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1f0ed825d68>




![png](output_9_1.png)



```python
data = pd.concat([sol_8_agg,diploma_agg],axis=1).dropna()
train = data[:110]
test = data[-20:]
```


```python
enet = lm.ElasticNetCV(l1_ratio=[.0000001,.000001,.000002,.000005,.00001,.00002,.00005,.0001,.0002,.0005,.001], eps=1e-6, n_alphas=100, cv=5)
enet.fit(train[['READING_SCORE','WRITING_SCORE','MATH_SCORE','SCIENCE_SCORE','READING_PASS_RATE','WRITING_PASS_RATE','MATH_PASS_RATE','SCIENCE_PASS_RATE']],train['DIPLOMA_RATE'])
```




    ElasticNetCV(alphas=None, copy_X=True, cv=5, eps=1e-06, fit_intercept=True,
           l1_ratio=[1e-07, 1e-06, 2e-06, 5e-06, 1e-05, 2e-05, 5e-05, 0.0001, 0.0002, 0.0005, 0.001],
           max_iter=1000, n_alphas=100, n_jobs=1, normalize=False,
           positive=False, precompute='auto', random_state=None,
           selection='cyclic', tol=0.0001, verbose=0)




```python
alpha = enet.alpha_
l1_ratio = enet.l1_ratio_
alpha, l1_ratio
```




    (33.072102401585575, 5.0000000000000004e-06)




```python
enet.coef_
```




    array([ 0.08773741, -0.00343186, -0.01659838,  0.08277926,  0.0983059 ,
           -0.03273777,  0.02206992,  0.05383283])




```python
score_enet = enet.score(test[['READING_SCORE','WRITING_SCORE','MATH_SCORE','SCIENCE_SCORE','READING_PASS_RATE','WRITING_PASS_RATE','MATH_PASS_RATE','SCIENCE_PASS_RATE']],test['DIPLOMA_RATE'])
score_enet
```




    0.58834991795860181




```python
enet_pos = lm.ElasticNetCV(l1_ratio=[0,.00001,.00005,.00008,.00009,.0001,.00011,.00012,.00015,.0002], eps=1e-6, n_alphas=100, cv=5, positive=True)
enet_pos.fit(train[['READING_SCORE','WRITING_SCORE','MATH_SCORE','SCIENCE_SCORE','READING_PASS_RATE','WRITING_PASS_RATE','MATH_PASS_RATE','SCIENCE_PASS_RATE']],train['DIPLOMA_RATE'])
```




    ElasticNetCV(alphas=None, copy_X=True, cv=5, eps=1e-06, fit_intercept=True,
           l1_ratio=[0, 1e-05, 5e-05, 8e-05, 9e-05, 0.0001, 0.00011, 0.00012, 0.00015, 0.0002],
           max_iter=1000, n_alphas=100, n_jobs=1, normalize=False,
           positive=True, precompute='auto', random_state=None,
           selection='cyclic', tol=0.0001, verbose=0)




```python
alpha_pos = enet_pos.alpha_
l1_ratio_pos = enet_pos.l1_ratio_
alpha_pos, l1_ratio_pos
```




    (30.843153388183278, 5.0000000000000002e-05)




```python
enet_pos.coef_
```




    array([ 0.0785652 ,  0.        ,  0.        ,  0.07328889,  0.09992707,
            0.        ,  0.        ,  0.05248289])




```python
score_enet_pos = enet_pos.score(test[['READING_SCORE','WRITING_SCORE','MATH_SCORE','SCIENCE_SCORE','READING_PASS_RATE','WRITING_PASS_RATE','MATH_PASS_RATE','SCIENCE_PASS_RATE']],test['DIPLOMA_RATE'])
score_enet_pos
```




    0.59804902073373956




```python
dropout_model = sm.OLS(data['DROPOUT_RATE'],sm.add_constant(data[['READING_PASS_RATE']]))
dropout_results = dropout_model.fit()
dropout_results.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>      <td>DROPOUT_RATE</td>   <th>  R-squared:         </th> <td>   0.370</td>
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.365</td>
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   75.10</td>
</tr>
<tr>
  <th>Date:</th>             <td>Wed, 25 May 2016</td> <th>  Prob (F-statistic):</th> <td>1.68e-14</td>
</tr>
<tr>
  <th>Time:</th>                 <td>12:54:16</td>     <th>  Log-Likelihood:    </th> <td> -342.46</td>
</tr>
<tr>
  <th>No. Observations:</th>      <td>   130</td>      <th>  AIC:               </th> <td>   688.9</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>   128</td>      <th>  BIC:               </th> <td>   694.6</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>     1</td>      <th>                     </th>     <td> </td>   
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
          <td></td>             <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th> <th>[95.0% Conf. Int.]</th> 
</tr>
<tr>
  <th>const</th>             <td>   33.1689</td> <td>    2.982</td> <td>   11.123</td> <td> 0.000</td> <td>   27.269    39.069</td>
</tr>
<tr>
  <th>READING_PASS_RATE</th> <td>   -0.3282</td> <td>    0.038</td> <td>   -8.666</td> <td> 0.000</td> <td>   -0.403    -0.253</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td> 1.890</td> <th>  Durbin-Watson:     </th> <td>   1.846</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.389</td> <th>  Jarque-Bera (JB):  </th> <td>   1.941</td>
</tr>
<tr>
  <th>Skew:</th>          <td> 0.255</td> <th>  Prob(JB):          </th> <td>   0.379</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 2.687</td> <th>  Cond. No.          </th> <td>    788.</td>
</tr>
</table>




```python
diploma_model = sm.OLS(data['DIPLOMA_RATE'],sm.add_constant(data[['READING_PASS_RATE','SCIENCE_PASS_RATE']]))
diploma_results = diploma_model.fit()
diploma_results.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>      <td>DIPLOMA_RATE</td>   <th>  R-squared:         </th> <td>   0.366</td>
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.356</td>
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   36.60</td>
</tr>
<tr>
  <th>Date:</th>             <td>Wed, 25 May 2016</td> <th>  Prob (F-statistic):</th> <td>2.80e-13</td>
</tr>
<tr>
  <th>Time:</th>                 <td>12:54:17</td>     <th>  Log-Likelihood:    </th> <td> -391.53</td>
</tr>
<tr>
  <th>No. Observations:</th>      <td>   130</td>      <th>  AIC:               </th> <td>   789.1</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>   127</td>      <th>  BIC:               </th> <td>   797.7</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>     2</td>      <th>                     </th>     <td> </td>   
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
          <td></td>             <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th> <th>[95.0% Conf. Int.]</th> 
</tr>
<tr>
  <th>const</th>             <td>   43.8305</td> <td>    5.697</td> <td>    7.693</td> <td> 0.000</td> <td>   32.557    55.104</td>
</tr>
<tr>
  <th>READING_PASS_RATE</th> <td>    0.3788</td> <td>    0.081</td> <td>    4.653</td> <td> 0.000</td> <td>    0.218     0.540</td>
</tr>
<tr>
  <th>SCIENCE_PASS_RATE</th> <td>    0.1414</td> <td>    0.095</td> <td>    1.484</td> <td> 0.140</td> <td>   -0.047     0.330</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td> 1.767</td> <th>  Durbin-Watson:     </th> <td>   1.960</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.413</td> <th>  Jarque-Bera (JB):  </th> <td>   1.534</td>
</tr>
<tr>
  <th>Skew:</th>          <td>-0.127</td> <th>  Prob(JB):          </th> <td>   0.464</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 2.532</td> <th>  Cond. No.          </th> <td>1.54e+03</td>
</tr>
</table>




```python
dropout_model = sm.RLM(data['DROPOUT_RATE'],sm.add_constant(data[['READING_SCORE','WRITING_SCORE','SCIENCE_SCORE']]))
dropout_results = dropout_model.fit()
dropout_results.summary()
```




<table class="simpletable">
<caption>Robust linear Model Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>    <td>DROPOUT_RATE</td>   <th>  No. Observations:  </th> <td>   130</td>
</tr>
<tr>
  <th>Model:</th>                 <td>RLM</td>       <th>  Df Residuals:      </th> <td>   126</td>
</tr>
<tr>
  <th>Method:</th>               <td>IRLS</td>       <th>  Df Model:          </th> <td>     3</td>
</tr>
<tr>
  <th>Norm:</th>                <td>HuberT</td>      <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Scale Est.:</th>            <td>mad</td>       <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Cov Type:</th>              <td>H1</td>        <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Date:</th>           <td>Wed, 25 May 2016</td> <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Time:</th>               <td>12:54:17</td>     <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>No. Iterations:</th>        <td>14</td>        <th>                     </th>    <td> </td>  
</tr>
</table>
<table class="simpletable">
<tr>
        <td></td>           <th>coef</th>     <th>std err</th>      <th>z</th>      <th>P>|z|</th> <th>[95.0% Conf. Int.]</th> 
</tr>
<tr>
  <th>const</th>         <td>   58.9182</td> <td>   19.547</td> <td>    3.014</td> <td> 0.003</td> <td>   20.607    97.229</td>
</tr>
<tr>
  <th>READING_SCORE</th> <td>   -0.1293</td> <td>    0.032</td> <td>   -4.010</td> <td> 0.000</td> <td>   -0.193    -0.066</td>
</tr>
<tr>
  <th>WRITING_SCORE</th> <td>    0.0920</td> <td>    0.070</td> <td>    1.322</td> <td> 0.186</td> <td>   -0.044     0.229</td>
</tr>
<tr>
  <th>SCIENCE_SCORE</th> <td>   -0.0692</td> <td>    0.038</td> <td>   -1.809</td> <td> 0.070</td> <td>   -0.144     0.006</td>
</tr>
</table>




```python
diploma_model = sm.RLM(data['DIPLOMA_RATE'],sm.add_constant(data[['READING_SCORE','SCIENCE_SCORE']]))
diploma_results = diploma_model.fit()
diploma_results.summary()
```




<table class="simpletable">
<caption>Robust linear Model Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>    <td>DIPLOMA_RATE</td>   <th>  No. Observations:  </th> <td>   130</td>
</tr>
<tr>
  <th>Model:</th>                 <td>RLM</td>       <th>  Df Residuals:      </th> <td>   127</td>
</tr>
<tr>
  <th>Method:</th>               <td>IRLS</td>       <th>  Df Model:          </th> <td>     2</td>
</tr>
<tr>
  <th>Norm:</th>                <td>HuberT</td>      <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Scale Est.:</th>            <td>mad</td>       <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Cov Type:</th>              <td>H1</td>        <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Date:</th>           <td>Wed, 25 May 2016</td> <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Time:</th>               <td>12:54:17</td>     <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>No. Iterations:</th>        <td>15</td>        <th>                     </th>    <td> </td>  
</tr>
</table>
<table class="simpletable">
<tr>
        <td></td>           <th>coef</th>     <th>std err</th>      <th>z</th>      <th>P>|z|</th> <th>[95.0% Conf. Int.]</th> 
</tr>
<tr>
  <th>const</th>         <td>  -20.6993</td> <td>   13.856</td> <td>   -1.494</td> <td> 0.135</td> <td>  -47.856     6.458</td>
</tr>
<tr>
  <th>READING_SCORE</th> <td>    0.1530</td> <td>    0.041</td> <td>    3.687</td> <td> 0.000</td> <td>    0.072     0.234</td>
</tr>
<tr>
  <th>SCIENCE_SCORE</th> <td>    0.0797</td> <td>    0.049</td> <td>    1.642</td> <td> 0.101</td> <td>   -0.015     0.175</td>
</tr>
</table>




```python
diploma_school = pd.read_csv('class2011_diploma_school.csv').drop('Unnamed: 0',axis=1)
diploma_school_agg = diploma_school[diploma_school.GENDER.isnull()&diploma_school.FEDERAL_RACE_CODE.isnull()&diploma_school.DISABILITY_FLAG.isnull()&diploma_school.LEP_FLAG.isnull()&diploma_school.DISADVANTAGED_FLAG.isnull()]
diploma_school_agg.index = diploma_school_agg[['DIV_NAME','SCH_NAME']]
diploma_school_agg = diploma_school_agg.drop(['DIV_NAME','SCH_NAME','GENDER','FEDERAL_RACE_CODE','DISABILITY_FLAG','LEP_FLAG','DISADVANTAGED_FLAG'],axis=1)
diploma_school_agg['DROPOUT_RATE'] = diploma_school_agg.DROPOUT_CNT/diploma_school_agg.COHORT_CNT
diploma_school_agg
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>COHORT_CNT</th>
      <th>DIPLOMA_RATE</th>
      <th>DROPOUT_RATE</th>
      <th>DIPLOMA_CNT</th>
      <th>DROPOUT_CNT</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>(Accomack County, Arcadia High)</th>
      <td>140</td>
      <td>80.00</td>
      <td>0.0857</td>
      <td>112.0000</td>
      <td>11.9980</td>
    </tr>
    <tr>
      <th>(Accomack County, Chincoteague High)</th>
      <td>52</td>
      <td>82.69</td>
      <td>0.1154</td>
      <td>42.9988</td>
      <td>6.0008</td>
    </tr>
    <tr>
      <th>(Accomack County, Nandua High)</th>
      <td>194</td>
      <td>76.80</td>
      <td>0.1443</td>
      <td>148.9920</td>
      <td>27.9942</td>
    </tr>
    <tr>
      <th>(Albemarle County, Albemarle High)</th>
      <td>460</td>
      <td>93.48</td>
      <td>0.0413</td>
      <td>430.0080</td>
      <td>18.9980</td>
    </tr>
    <tr>
      <th>(Albemarle County, Monticello High)</th>
      <td>302</td>
      <td>92.38</td>
      <td>0.0397</td>
      <td>278.9876</td>
      <td>11.9894</td>
    </tr>
    <tr>
      <th>(Albemarle County, Murray High)</th>
      <td>30</td>
      <td>50.00</td>
      <td>0.1333</td>
      <td>15.0000</td>
      <td>3.9990</td>
    </tr>
    <tr>
      <th>(Albemarle County, Western Albemarle High)</th>
      <td>239</td>
      <td>97.91</td>
      <td>0.0084</td>
      <td>234.0049</td>
      <td>2.0076</td>
    </tr>
    <tr>
      <th>(Alexandria City, T.C. Williams High)</th>
      <td>817</td>
      <td>79.19</td>
      <td>0.1506</td>
      <td>646.9823</td>
      <td>123.0402</td>
    </tr>
    <tr>
      <th>(Alleghany County, Alleghany High)</th>
      <td>213</td>
      <td>92.96</td>
      <td>0.0563</td>
      <td>198.0048</td>
      <td>11.9919</td>
    </tr>
    <tr>
      <th>(Amelia County, Amelia County High)</th>
      <td>131</td>
      <td>84.73</td>
      <td>0.0840</td>
      <td>110.9963</td>
      <td>11.0040</td>
    </tr>
    <tr>
      <th>(Amherst County, Amherst County High)</th>
      <td>394</td>
      <td>87.56</td>
      <td>0.0482</td>
      <td>344.9864</td>
      <td>18.9908</td>
    </tr>
    <tr>
      <th>(Appomattox County, Appomattox County High)</th>
      <td>191</td>
      <td>82.72</td>
      <td>0.0995</td>
      <td>157.9952</td>
      <td>19.0045</td>
    </tr>
    <tr>
      <th>(Arlington County, Wakefield High)</th>
      <td>426</td>
      <td>74.88</td>
      <td>0.1948</td>
      <td>318.9888</td>
      <td>82.9848</td>
    </tr>
    <tr>
      <th>(Arlington County, Washington-Lee High)</th>
      <td>518</td>
      <td>90.15</td>
      <td>0.0734</td>
      <td>466.9770</td>
      <td>38.0212</td>
    </tr>
    <tr>
      <th>(Arlington County, Yorktown High)</th>
      <td>507</td>
      <td>95.27</td>
      <td>0.0414</td>
      <td>483.0189</td>
      <td>20.9898</td>
    </tr>
    <tr>
      <th>(Augusta County, Buffalo Gap High)</th>
      <td>155</td>
      <td>83.23</td>
      <td>0.1161</td>
      <td>129.0065</td>
      <td>17.9955</td>
    </tr>
    <tr>
      <th>(Augusta County, Fort Defiance High)</th>
      <td>223</td>
      <td>89.24</td>
      <td>0.0673</td>
      <td>199.0052</td>
      <td>15.0079</td>
    </tr>
    <tr>
      <th>(Augusta County, Riverheads High)</th>
      <td>138</td>
      <td>89.13</td>
      <td>0.0797</td>
      <td>122.9994</td>
      <td>10.9986</td>
    </tr>
    <tr>
      <th>(Augusta County, Stuarts Draft High)</th>
      <td>160</td>
      <td>88.75</td>
      <td>0.0688</td>
      <td>142.0000</td>
      <td>11.0080</td>
    </tr>
    <tr>
      <th>(Augusta County, Wilson Memorial High)</th>
      <td>208</td>
      <td>87.50</td>
      <td>0.1010</td>
      <td>182.0000</td>
      <td>21.0080</td>
    </tr>
    <tr>
      <th>(Bath County, Bath County High)</th>
      <td>55</td>
      <td>94.55</td>
      <td>0.0545</td>
      <td>52.0025</td>
      <td>2.9975</td>
    </tr>
    <tr>
      <th>(Bedford County, Jefferson Forest High)</th>
      <td>326</td>
      <td>93.56</td>
      <td>0.0092</td>
      <td>305.0056</td>
      <td>2.9992</td>
    </tr>
    <tr>
      <th>(Bedford County, Liberty High)</th>
      <td>268</td>
      <td>89.18</td>
      <td>0.0485</td>
      <td>239.0024</td>
      <td>12.9980</td>
    </tr>
    <tr>
      <th>(Bedford County, Staunton River High)</th>
      <td>299</td>
      <td>88.29</td>
      <td>0.0535</td>
      <td>263.9871</td>
      <td>15.9965</td>
    </tr>
    <tr>
      <th>(Bland County, Bland High)</th>
      <td>42</td>
      <td>85.71</td>
      <td>0.0476</td>
      <td>35.9982</td>
      <td>1.9992</td>
    </tr>
    <tr>
      <th>(Bland County, Rocky Gap High)</th>
      <td>41</td>
      <td>90.24</td>
      <td>0.0244</td>
      <td>36.9984</td>
      <td>1.0004</td>
    </tr>
    <tr>
      <th>(Botetourt County, James River High)</th>
      <td>139</td>
      <td>89.21</td>
      <td>0.0576</td>
      <td>124.0019</td>
      <td>8.0064</td>
    </tr>
    <tr>
      <th>(Botetourt County, Lord Botetourt High)</th>
      <td>259</td>
      <td>91.89</td>
      <td>0.0502</td>
      <td>237.9951</td>
      <td>13.0018</td>
    </tr>
    <tr>
      <th>(Bristol City, Virginia High)</th>
      <td>166</td>
      <td>80.12</td>
      <td>0.1024</td>
      <td>132.9992</td>
      <td>16.9984</td>
    </tr>
    <tr>
      <th>(Brunswick County, Brunswick High)</th>
      <td>194</td>
      <td>78.35</td>
      <td>0.1495</td>
      <td>151.9990</td>
      <td>29.0030</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>(Virginia Beach City, Salem High)</th>
      <td>497</td>
      <td>88.13</td>
      <td>0.0503</td>
      <td>438.0061</td>
      <td>24.9991</td>
    </tr>
    <tr>
      <th>(Virginia Beach City, Tallwood High)</th>
      <td>554</td>
      <td>90.07</td>
      <td>0.0487</td>
      <td>498.9878</td>
      <td>26.9798</td>
    </tr>
    <tr>
      <th>(Virginia School for the Deaf and Blind-Staunton, Virginia School For Deaf)</th>
      <td>13</td>
      <td>84.62</td>
      <td>0.1538</td>
      <td>11.0006</td>
      <td>1.9994</td>
    </tr>
    <tr>
      <th>(Warren County, Skyline High)</th>
      <td>239</td>
      <td>92.05</td>
      <td>0.0502</td>
      <td>219.9995</td>
      <td>11.9978</td>
    </tr>
    <tr>
      <th>(Warren County, Warren County High)</th>
      <td>202</td>
      <td>91.09</td>
      <td>0.0594</td>
      <td>184.0018</td>
      <td>11.9988</td>
    </tr>
    <tr>
      <th>(Washington County, Abingdon High)</th>
      <td>258</td>
      <td>88.76</td>
      <td>0.0194</td>
      <td>229.0008</td>
      <td>5.0052</td>
    </tr>
    <tr>
      <th>(Washington County, Holston High)</th>
      <td>85</td>
      <td>88.24</td>
      <td>0.0353</td>
      <td>75.0040</td>
      <td>3.0005</td>
    </tr>
    <tr>
      <th>(Washington County, John S. Battle High)</th>
      <td>165</td>
      <td>86.06</td>
      <td>0.0788</td>
      <td>141.9990</td>
      <td>13.0020</td>
    </tr>
    <tr>
      <th>(Washington County, Patrick Henry High)</th>
      <td>104</td>
      <td>92.31</td>
      <td>0.0192</td>
      <td>96.0024</td>
      <td>1.9968</td>
    </tr>
    <tr>
      <th>(Waynesboro City, Waynesboro High)</th>
      <td>241</td>
      <td>79.67</td>
      <td>0.0705</td>
      <td>192.0047</td>
      <td>16.9905</td>
    </tr>
    <tr>
      <th>(West Point, West Point High)</th>
      <td>57</td>
      <td>96.49</td>
      <td>0.0000</td>
      <td>54.9993</td>
      <td>0.0000</td>
    </tr>
    <tr>
      <th>(Westmoreland County, Washington &amp; Lee High)</th>
      <td>147</td>
      <td>75.51</td>
      <td>0.1429</td>
      <td>110.9997</td>
      <td>21.0063</td>
    </tr>
    <tr>
      <th>(Williamsburg-James City County, Jamestown High)</th>
      <td>323</td>
      <td>87.31</td>
      <td>0.0310</td>
      <td>282.0113</td>
      <td>10.0130</td>
    </tr>
    <tr>
      <th>(Williamsburg-James City County, Lafayette High)</th>
      <td>273</td>
      <td>85.71</td>
      <td>0.0440</td>
      <td>233.9883</td>
      <td>12.0120</td>
    </tr>
    <tr>
      <th>(Williamsburg-James City County, Warhill High)</th>
      <td>287</td>
      <td>88.50</td>
      <td>0.0244</td>
      <td>253.9950</td>
      <td>7.0028</td>
    </tr>
    <tr>
      <th>(Winchester City, John Handley High)</th>
      <td>275</td>
      <td>88.36</td>
      <td>0.0873</td>
      <td>242.9900</td>
      <td>24.0075</td>
    </tr>
    <tr>
      <th>(Wise County, Appalachia High)</th>
      <td>59</td>
      <td>79.66</td>
      <td>0.0508</td>
      <td>46.9994</td>
      <td>2.9972</td>
    </tr>
    <tr>
      <th>(Wise County, Coeburn High)</th>
      <td>98</td>
      <td>82.65</td>
      <td>0.0918</td>
      <td>80.9970</td>
      <td>8.9964</td>
    </tr>
    <tr>
      <th>(Wise County, J.J. Kelly High)</th>
      <td>119</td>
      <td>91.60</td>
      <td>0.0420</td>
      <td>109.0040</td>
      <td>4.9980</td>
    </tr>
    <tr>
      <th>(Wise County, Pound High)</th>
      <td>62</td>
      <td>90.32</td>
      <td>0.0161</td>
      <td>55.9984</td>
      <td>0.9982</td>
    </tr>
    <tr>
      <th>(Wise County, Powell Valley High)</th>
      <td>144</td>
      <td>84.72</td>
      <td>0.0417</td>
      <td>121.9968</td>
      <td>6.0048</td>
    </tr>
    <tr>
      <th>(Wise County, St. Paul High)</th>
      <td>47</td>
      <td>97.87</td>
      <td>0.0213</td>
      <td>45.9989</td>
      <td>1.0011</td>
    </tr>
    <tr>
      <th>(Wythe County, Fort Chiswell High)</th>
      <td>144</td>
      <td>84.72</td>
      <td>0.0833</td>
      <td>121.9968</td>
      <td>11.9952</td>
    </tr>
    <tr>
      <th>(Wythe County, George Wythe High)</th>
      <td>108</td>
      <td>80.56</td>
      <td>0.1111</td>
      <td>87.0048</td>
      <td>11.9988</td>
    </tr>
    <tr>
      <th>(Wythe County, Rural Retreat High)</th>
      <td>75</td>
      <td>72.00</td>
      <td>0.1200</td>
      <td>54.0000</td>
      <td>9.0000</td>
    </tr>
    <tr>
      <th>(York County, Bruton High)</th>
      <td>181</td>
      <td>85.64</td>
      <td>0.0939</td>
      <td>155.0084</td>
      <td>16.9959</td>
    </tr>
    <tr>
      <th>(York County, Grafton High)</th>
      <td>309</td>
      <td>95.79</td>
      <td>0.0194</td>
      <td>295.9911</td>
      <td>5.9946</td>
    </tr>
    <tr>
      <th>(York County, Tabb High)</th>
      <td>278</td>
      <td>98.20</td>
      <td>0.0144</td>
      <td>272.9960</td>
      <td>4.0032</td>
    </tr>
    <tr>
      <th>(York County, York High)</th>
      <td>235</td>
      <td>92.34</td>
      <td>0.0468</td>
      <td>216.9990</td>
      <td>10.9980</td>
    </tr>
    <tr>
      <th>(York County, York River Academy)</th>
      <td>10</td>
      <td>90.00</td>
      <td>0.0000</td>
      <td>9.0000</td>
      <td>0.0000</td>
    </tr>
  </tbody>
</table>
<p>335 rows × 5 columns</p>
</div>




```python
college_school = pd.read_csv('class2011_college_school.csv').drop('Unnamed: 0',axis=1)
college_school_agg = college_school[college_school.GENDER.isnull()&college_school.FEDERAL_RACE_CODE.isnull()&college_school.DISABILITY_FLAG.isnull()&college_school.LEP_FLAG.isnull()&college_school.DISADVANTAGED_FLAG.isnull()&college_school.PS_INSTITUTION_TYPE.isnull()]
college_school_agg.index = college_school_agg[['DIV_NAME','SCH_NAME']]
college_school_agg = college_school_agg.drop(['DIV_NAME','SCH_NAME','GENDER','FEDERAL_RACE_CODE','DISABILITY_FLAG','LEP_FLAG','DISADVANTAGED_FLAG','COHORT_GRADUATE_CNT','PS_INSTITUTION_TYPE'],axis=1)
```

    C:\Program Files\Anaconda\lib\site-packages\IPython\core\interactiveshell.py:2723: DtypeWarning: Columns (6,7) have mixed types. Specify dtype option on import or set low_memory=False.
      interactivity=interactivity, compiler=compiler, result=result)
    


```python
ps_data = pd.concat([college_school_agg,diploma_school_agg],axis=1).dropna()
ps_data['PS_RATE'] = ps_data.PS_ENROLLMENT_CNT/ps_data.COHORT_CNT
ps_data['INV_DROPOUT_RATE'] = (1-ps_data.DROPOUT_RATE)
ps_data.DIPLOMA_RATE = ps_data.DIPLOMA_RATE/100
ps_data['LOG_PS_RATE'] = np.log(ps_data.PS_RATE)
ps_data['LOG_DIPLOMA_RATE'] = np.log(ps_data.DIPLOMA_RATE)
ps_data['LOG_INV_DROPOUT_RATE'] = np.log(ps_data.INV_DROPOUT_RATE)
ps_data.plot.scatter(2,8)
stats.linregress(ps_data['DIPLOMA_RATE'],ps_data['LOG_PS_RATE'])
```




    LinregressResult(slope=3.1534386311667846, intercept=-3.4886172277646175, rvalue=0.82803418911983262, pvalue=1.1870968825980098e-81, stderr=0.11992775294374219)




![png](output_25_1.png)



```python
diploma_ps_model = sm.RLM(ps_data['LOG_PS_RATE'],sm.add_constant(ps_data['DIPLOMA_RATE']))
diploma_ps_results = diploma_ps_model.fit()
diploma_ps_results.summary()
```




<table class="simpletable">
<caption>Robust linear Model Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>     <td>LOG_PS_RATE</td>   <th>  No. Observations:  </th> <td>   319</td>
</tr>
<tr>
  <th>Model:</th>                 <td>RLM</td>       <th>  Df Residuals:      </th> <td>   317</td>
</tr>
<tr>
  <th>Method:</th>               <td>IRLS</td>       <th>  Df Model:          </th> <td>     1</td>
</tr>
<tr>
  <th>Norm:</th>                <td>HuberT</td>      <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Scale Est.:</th>            <td>mad</td>       <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Cov Type:</th>              <td>H1</td>        <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Date:</th>           <td>Wed, 25 May 2016</td> <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Time:</th>               <td>15:19:51</td>     <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>No. Iterations:</th>        <td>22</td>        <th>                     </th>    <td> </td>  
</tr>
</table>
<table class="simpletable">
<tr>
        <td></td>          <th>coef</th>     <th>std err</th>      <th>z</th>      <th>P>|z|</th> <th>[95.0% Conf. Int.]</th> 
</tr>
<tr>
  <th>const</th>        <td>   -3.5041</td> <td>    0.095</td> <td>  -37.036</td> <td> 0.000</td> <td>   -3.690    -3.319</td>
</tr>
<tr>
  <th>DIPLOMA_RATE</th> <td>    3.1849</td> <td>    0.109</td> <td>   29.308</td> <td> 0.000</td> <td>    2.972     3.398</td>
</tr>
</table>




```python
ps_data.plot.scatter(7,8)
stats.linregress(ps_data['INV_DROPOUT_RATE'],ps_data['LOG_PS_RATE'])
```




    LinregressResult(slope=4.7108548919222555, intercept=-5.1359584266920191, rvalue=0.76679625922627759, pvalue=5.3774140644958552e-63, stderr=0.22148845927033414)




![png](output_27_1.png)



```python
dropout_ps_model = sm.RLM(ps_data['LOG_PS_RATE'],sm.add_constant(ps_data['INV_DROPOUT_RATE']))
dropout_ps_results = dropout_ps_model.fit()
dropout_ps_results.summary()
```




<table class="simpletable">
<caption>Robust linear Model Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>     <td>LOG_PS_RATE</td>   <th>  No. Observations:  </th> <td>   319</td>
</tr>
<tr>
  <th>Model:</th>                 <td>RLM</td>       <th>  Df Residuals:      </th> <td>   317</td>
</tr>
<tr>
  <th>Method:</th>               <td>IRLS</td>       <th>  Df Model:          </th> <td>     1</td>
</tr>
<tr>
  <th>Norm:</th>                <td>HuberT</td>      <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Scale Est.:</th>            <td>mad</td>       <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Cov Type:</th>              <td>H1</td>        <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Date:</th>           <td>Wed, 25 May 2016</td> <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Time:</th>               <td>15:20:28</td>     <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>No. Iterations:</th>        <td>25</td>        <th>                     </th>    <td> </td>  
</tr>
</table>
<table class="simpletable">
<tr>
          <td></td>            <th>coef</th>     <th>std err</th>      <th>z</th>      <th>P>|z|</th> <th>[95.0% Conf. Int.]</th> 
</tr>
<tr>
  <th>const</th>            <td>   -5.0266</td> <td>    0.197</td> <td>  -25.485</td> <td> 0.000</td> <td>   -5.413    -4.640</td>
</tr>
<tr>
  <th>INV_DROPOUT_RATE</th> <td>    4.6111</td> <td>    0.212</td> <td>   21.768</td> <td> 0.000</td> <td>    4.196     5.026</td>
</tr>
</table>




```python
diploma_school_disadvantaged = diploma_school[diploma_school.GENDER.isnull()&diploma_school.FEDERAL_RACE_CODE.isnull()&diploma_school.DISABILITY_FLAG.isnull()&diploma_school.LEP_FLAG.isnull()&(diploma_school.DISADVANTAGED_FLAG=='Y')]
diploma_school_disadvantaged.index = diploma_school_disadvantaged[['DIV_NAME','SCH_NAME']]
diploma_school_disadvantaged = diploma_school_disadvantaged.drop(['DIV_NAME','SCH_NAME','GENDER','FEDERAL_RACE_CODE','DISABILITY_FLAG','LEP_FLAG','DISADVANTAGED_FLAG'],axis=1)
diploma_school_disadvantaged['DROPOUT_RATE'] = diploma_school_disadvantaged.DROPOUT_CNT/diploma_school_disadvantaged.COHORT_CNT

college_school_disadvantaged = college_school[college_school.GENDER.isnull()&college_school.FEDERAL_RACE_CODE.isnull()&college_school.DISABILITY_FLAG.isnull()&college_school.LEP_FLAG.isnull()&(college_school.DISADVANTAGED_FLAG=='Y')&college_school.PS_INSTITUTION_TYPE.isnull()]
college_school_disadvantaged.index = college_school_disadvantaged[['DIV_NAME','SCH_NAME']]
college_school_disadvantaged = college_school_disadvantaged.drop(['DIV_NAME','SCH_NAME','GENDER','FEDERAL_RACE_CODE','DISABILITY_FLAG','LEP_FLAG','DISADVANTAGED_FLAG','COHORT_GRADUATE_CNT','PS_INSTITUTION_TYPE'],axis=1)
```


```python
ps_data_disadvantaged = pd.concat([college_school_disadvantaged,diploma_school_disadvantaged],axis=1).dropna()
ps_data_disadvantaged['PS_RATE'] = ps_data_disadvantaged.PS_ENROLLMENT_CNT/ps_data_disadvantaged.COHORT_CNT
ps_data_disadvantaged['INV_DROPOUT_RATE'] = (1-ps_data_disadvantaged.DROPOUT_RATE)
ps_data_disadvantaged.DIPLOMA_RATE = ps_data_disadvantaged.DIPLOMA_RATE/100
ps_data_disadvantaged['LOG_PS_RATE'] = np.log(ps_data_disadvantaged.PS_RATE)
ps_data_disadvantaged['LOG_DIPLOMA_RATE'] = np.log(ps_data_disadvantaged.DIPLOMA_RATE)
ps_data_disadvantaged['LOG_INV_DROPOUT_RATE'] = np.log(ps_data_disadvantaged.INV_DROPOUT_RATE)
ps_data_disadvantaged.plot.scatter(2,8)
stats.linregress(ps_data_disadvantaged['DIPLOMA_RATE'],ps_data_disadvantaged['LOG_PS_RATE'])
```




    LinregressResult(slope=2.428634207363773, intercept=-3.1272227672043593, rvalue=0.60254311764207269, pvalue=4.0514959400915108e-32, stderr=0.18299726977580449)




![png](output_30_1.png)



```python
diploma_ps_model_disadvantaged = sm.RLM(ps_data_disadvantaged['LOG_PS_RATE'],sm.add_constant(ps_data_disadvantaged['DIPLOMA_RATE']))
diploma_ps_results_disadvantaged = diploma_ps_model_disadvantaged.fit()
diploma_ps_results_disadvantaged.summary()
```




<table class="simpletable">
<caption>Robust linear Model Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>     <td>LOG_PS_RATE</td>   <th>  No. Observations:  </th> <td>   311</td>
</tr>
<tr>
  <th>Model:</th>                 <td>RLM</td>       <th>  Df Residuals:      </th> <td>   309</td>
</tr>
<tr>
  <th>Method:</th>               <td>IRLS</td>       <th>  Df Model:          </th> <td>     1</td>
</tr>
<tr>
  <th>Norm:</th>                <td>HuberT</td>      <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Scale Est.:</th>            <td>mad</td>       <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Cov Type:</th>              <td>H1</td>        <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Date:</th>           <td>Wed, 25 May 2016</td> <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Time:</th>               <td>15:21:09</td>     <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>No. Iterations:</th>        <td>19</td>        <th>                     </th>    <td> </td>  
</tr>
</table>
<table class="simpletable">
<tr>
        <td></td>          <th>coef</th>     <th>std err</th>      <th>z</th>      <th>P>|z|</th> <th>[95.0% Conf. Int.]</th> 
</tr>
<tr>
  <th>const</th>        <td>   -3.0129</td> <td>    0.134</td> <td>  -22.496</td> <td> 0.000</td> <td>   -3.275    -2.750</td>
</tr>
<tr>
  <th>DIPLOMA_RATE</th> <td>    2.3136</td> <td>    0.162</td> <td>   14.256</td> <td> 0.000</td> <td>    1.996     2.632</td>
</tr>
</table>




```python
diploma_school_disadvantaged_N = diploma_school[diploma_school.GENDER.isnull()&diploma_school.FEDERAL_RACE_CODE.isnull()&diploma_school.DISABILITY_FLAG.isnull()&diploma_school.LEP_FLAG.isnull()&(diploma_school.DISADVANTAGED_FLAG=='N')]
diploma_school_disadvantaged_N.index = diploma_school_disadvantaged_N[['DIV_NAME','SCH_NAME']]
diploma_school_disadvantaged_N = diploma_school_disadvantaged_N.drop(['DIV_NAME','SCH_NAME','GENDER','FEDERAL_RACE_CODE','DISABILITY_FLAG','LEP_FLAG','DISADVANTAGED_FLAG'],axis=1)
diploma_school_disadvantaged_N['DROPOUT_RATE'] = diploma_school_disadvantaged_N.DROPOUT_CNT/diploma_school_disadvantaged_N.COHORT_CNT

college_school_disadvantaged_N = college_school[college_school.GENDER.isnull()&college_school.FEDERAL_RACE_CODE.isnull()&college_school.DISABILITY_FLAG.isnull()&college_school.LEP_FLAG.isnull()&(college_school.DISADVANTAGED_FLAG=='N')&college_school.PS_INSTITUTION_TYPE.isnull()]
college_school_disadvantaged_N.index = college_school_disadvantaged_N[['DIV_NAME','SCH_NAME']]
college_school_disadvantaged_N = college_school_disadvantaged_N.drop(['DIV_NAME','SCH_NAME','GENDER','FEDERAL_RACE_CODE','DISABILITY_FLAG','LEP_FLAG','DISADVANTAGED_FLAG','COHORT_GRADUATE_CNT','PS_INSTITUTION_TYPE'],axis=1)
```


```python
ps_data_disadvantaged_N = pd.concat([college_school_disadvantaged_N,diploma_school_disadvantaged_N],axis=1).dropna()
ps_data_disadvantaged_N['PS_RATE'] = ps_data_disadvantaged_N.PS_ENROLLMENT_CNT/ps_data_disadvantaged_N.COHORT_CNT
ps_data_disadvantaged_N['INV_DROPOUT_RATE'] = (1-ps_data_disadvantaged_N.DROPOUT_RATE)
ps_data_disadvantaged_N.DIPLOMA_RATE = ps_data_disadvantaged_N.DIPLOMA_RATE/100
ps_data_disadvantaged_N['LOG_PS_RATE'] = np.log(ps_data_disadvantaged_N.PS_RATE)
ps_data_disadvantaged_N['LOG_DIPLOMA_RATE'] = np.log(ps_data_disadvantaged_N.DIPLOMA_RATE)
ps_data_disadvantaged_N['LOG_INV_DROPOUT_RATE'] = np.log(ps_data_disadvantaged_N.INV_DROPOUT_RATE)
ps_data_disadvantaged_N.plot.scatter(2,8)
stats.linregress(ps_data_disadvantaged_N['DIPLOMA_RATE'],ps_data_disadvantaged_N['LOG_PS_RATE'])
```




    LinregressResult(slope=2.9909716501549579, intercept=-3.2803207246200765, rvalue=0.8526537758156274, pvalue=4.2611489170926234e-91, stderr=0.10310095173442614)




![png](output_33_1.png)



```python
diploma_ps_model_disadvantaged_N = sm.RLM(ps_data_disadvantaged_N['LOG_PS_RATE'],sm.add_constant(ps_data_disadvantaged_N['DIPLOMA_RATE']))
diploma_ps_results_disadvantaged_N = diploma_ps_model_disadvantaged_N.fit()
diploma_ps_results_disadvantaged_N.summary()
```




<table class="simpletable">
<caption>Robust linear Model Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>     <td>LOG_PS_RATE</td>   <th>  No. Observations:  </th> <td>   318</td>
</tr>
<tr>
  <th>Model:</th>                 <td>RLM</td>       <th>  Df Residuals:      </th> <td>   316</td>
</tr>
<tr>
  <th>Method:</th>               <td>IRLS</td>       <th>  Df Model:          </th> <td>     1</td>
</tr>
<tr>
  <th>Norm:</th>                <td>HuberT</td>      <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Scale Est.:</th>            <td>mad</td>       <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Cov Type:</th>              <td>H1</td>        <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Date:</th>           <td>Wed, 25 May 2016</td> <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Time:</th>               <td>15:21:39</td>     <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>No. Iterations:</th>        <td>32</td>        <th>                     </th>    <td> </td>  
</tr>
</table>
<table class="simpletable">
<tr>
        <td></td>          <th>coef</th>     <th>std err</th>      <th>z</th>      <th>P>|z|</th> <th>[95.0% Conf. Int.]</th> 
</tr>
<tr>
  <th>const</th>        <td>   -3.1554</td> <td>    0.081</td> <td>  -39.175</td> <td> 0.000</td> <td>   -3.313    -2.997</td>
</tr>
<tr>
  <th>DIPLOMA_RATE</th> <td>    2.8646</td> <td>    0.091</td> <td>   31.554</td> <td> 0.000</td> <td>    2.687     3.043</td>
</tr>
</table>




```python
diploma_school_lep = diploma_school[diploma_school.GENDER.isnull()&diploma_school.FEDERAL_RACE_CODE.isnull()&diploma_school.DISABILITY_FLAG.isnull()&(diploma_school.LEP_FLAG=='Y')&diploma_school.DISADVANTAGED_FLAG.isnull()]
diploma_school_lep.index = diploma_school_lep[['DIV_NAME','SCH_NAME']]
diploma_school_lep = diploma_school_lep.drop(['DIV_NAME','SCH_NAME','GENDER','FEDERAL_RACE_CODE','DISABILITY_FLAG','LEP_FLAG','DISADVANTAGED_FLAG'],axis=1)
diploma_school_lep['DROPOUT_RATE'] = diploma_school_disadvantaged_N.DROPOUT_CNT/diploma_school_disadvantaged_N.COHORT_CNT

college_school_lep = college_school[college_school.GENDER.isnull()&college_school.FEDERAL_RACE_CODE.isnull()&college_school.DISABILITY_FLAG.isnull()&(college_school.LEP_FLAG=='Y')&college_school.DISADVANTAGED_FLAG.isnull()&college_school.PS_INSTITUTION_TYPE.isnull()]
college_school_lep.index = college_school_lep[['DIV_NAME','SCH_NAME']]
college_school_lep = college_school_lep.drop(['DIV_NAME','SCH_NAME','GENDER','FEDERAL_RACE_CODE','DISABILITY_FLAG','LEP_FLAG','DISADVANTAGED_FLAG','COHORT_GRADUATE_CNT','PS_INSTITUTION_TYPE'],axis=1)

```


```python
ps_data_lep = pd.concat([college_school_lep,diploma_school_lep],axis=1).dropna()
ps_data_lep['PS_RATE'] = ps_data_lep.PS_ENROLLMENT_CNT/ps_data_lep.COHORT_CNT
ps_data_lep['INV_DROPOUT_RATE'] = (1-ps_data_lep.DROPOUT_RATE)
ps_data_lep.DIPLOMA_RATE = ps_data_lep.DIPLOMA_RATE/100
ps_data_lep['LOG_PS_RATE'] = np.log(ps_data_lep.PS_RATE)
ps_data_lep['LOG_DIPLOMA_RATE'] = np.log(ps_data_lep.DIPLOMA_RATE)
ps_data_lep['LOG_INV_DROPOUT_RATE'] = np.log(ps_data_lep.INV_DROPOUT_RATE)
ps_data_lep.plot.scatter(2,8)
stats.linregress(ps_data_lep['DIPLOMA_RATE'],ps_data_lep['LOG_PS_RATE'])
```




    LinregressResult(slope=2.7682223276673001, intercept=-2.9629707491574724, rvalue=0.6840196250250189, pvalue=9.7001573570421066e-12, stderr=0.34317858123598932)




![png](output_36_1.png)



```python
diploma_ps_model_lep = sm.RLM(ps_data_lep['LOG_PS_RATE'],sm.add_constant(ps_data_lep['DIPLOMA_RATE']))
diploma_ps_results_lep = diploma_ps_model_lep.fit()
diploma_ps_results_lep.summary()
```




<table class="simpletable">
<caption>Robust linear Model Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>     <td>LOG_PS_RATE</td>   <th>  No. Observations:  </th> <td>    76</td>
</tr>
<tr>
  <th>Model:</th>                 <td>RLM</td>       <th>  Df Residuals:      </th> <td>    74</td>
</tr>
<tr>
  <th>Method:</th>               <td>IRLS</td>       <th>  Df Model:          </th> <td>     1</td>
</tr>
<tr>
  <th>Norm:</th>                <td>HuberT</td>      <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Scale Est.:</th>            <td>mad</td>       <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Cov Type:</th>              <td>H1</td>        <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Date:</th>           <td>Wed, 25 May 2016</td> <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Time:</th>               <td>15:29:02</td>     <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>No. Iterations:</th>        <td>19</td>        <th>                     </th>    <td> </td>  
</tr>
</table>
<table class="simpletable">
<tr>
        <td></td>          <th>coef</th>     <th>std err</th>      <th>z</th>      <th>P>|z|</th> <th>[95.0% Conf. Int.]</th> 
</tr>
<tr>
  <th>const</th>        <td>   -2.5772</td> <td>    0.220</td> <td>  -11.731</td> <td> 0.000</td> <td>   -3.008    -2.147</td>
</tr>
<tr>
  <th>DIPLOMA_RATE</th> <td>    2.3379</td> <td>    0.275</td> <td>    8.513</td> <td> 0.000</td> <td>    1.800     2.876</td>
</tr>
</table>




```python
diploma_school_lep_N = diploma_school[diploma_school.GENDER.isnull()&diploma_school.FEDERAL_RACE_CODE.isnull()&diploma_school.DISABILITY_FLAG.isnull()&(diploma_school.LEP_FLAG=='N')&diploma_school.DISADVANTAGED_FLAG.isnull()]
diploma_school_lep_N.index = diploma_school_lep_N[['DIV_NAME','SCH_NAME']]
diploma_school_lep_N = diploma_school_lep_N.drop(['DIV_NAME','SCH_NAME','GENDER','FEDERAL_RACE_CODE','DISABILITY_FLAG','LEP_FLAG','DISADVANTAGED_FLAG'],axis=1)
diploma_school_lep_N['DROPOUT_RATE'] = diploma_school_lep_N.DROPOUT_CNT/diploma_school_lep_N.COHORT_CNT

college_school_lep_N = college_school[college_school.GENDER.isnull()&college_school.FEDERAL_RACE_CODE.isnull()&college_school.DISABILITY_FLAG.isnull()&(college_school.LEP_FLAG=='N')&college_school.DISADVANTAGED_FLAG.isnull()&college_school.PS_INSTITUTION_TYPE.isnull()]
college_school_lep_N.index = college_school_lep_N[['DIV_NAME','SCH_NAME']]
college_school_lep_N = college_school_lep_N.drop(['DIV_NAME','SCH_NAME','GENDER','FEDERAL_RACE_CODE','DISABILITY_FLAG','LEP_FLAG','DISADVANTAGED_FLAG','COHORT_GRADUATE_CNT','PS_INSTITUTION_TYPE'],axis=1)

```


```python
ps_data_lep_N = pd.concat([college_school_lep_N,diploma_school_lep_N],axis=1).dropna()
ps_data_lep_N['PS_RATE'] = ps_data_lep_N.PS_ENROLLMENT_CNT/ps_data_lep_N.COHORT_CNT
ps_data_lep_N['INV_DROPOUT_RATE'] = (1-ps_data_lep_N.DROPOUT_RATE)
ps_data_lep_N.DIPLOMA_RATE = ps_data_lep_N.DIPLOMA_RATE/100
ps_data_lep_N['LOG_PS_RATE'] = np.log(ps_data_lep_N.PS_RATE)
ps_data_lep_N['LOG_DIPLOMA_RATE'] = np.log(ps_data_lep_N.DIPLOMA_RATE)
ps_data_lep_N['LOG_INV_DROPOUT_RATE'] = np.log(ps_data_lep_N.INV_DROPOUT_RATE)
ps_data_lep_N.plot.scatter(2,8)
stats.linregress(ps_data_lep_N['DIPLOMA_RATE'],ps_data_lep_N['LOG_PS_RATE'])
```




    LinregressResult(slope=3.1342852685381217, intercept=-3.4804105988023859, rvalue=0.8260740481900779, pvalue=6.0511390423794183e-81, stderr=0.12009676199209908)




![png](output_39_1.png)



```python
diploma_ps_model_lep_N = sm.RLM(ps_data_lep_N['LOG_PS_RATE'],sm.add_constant(ps_data_lep_N['DIPLOMA_RATE']))
diploma_ps_results_lep_N = diploma_ps_model_lep_N.fit()
diploma_ps_results_lep_N.summary()
```




<table class="simpletable">
<caption>Robust linear Model Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>     <td>LOG_PS_RATE</td>   <th>  No. Observations:  </th> <td>   319</td>
</tr>
<tr>
  <th>Model:</th>                 <td>RLM</td>       <th>  Df Residuals:      </th> <td>   317</td>
</tr>
<tr>
  <th>Method:</th>               <td>IRLS</td>       <th>  Df Model:          </th> <td>     1</td>
</tr>
<tr>
  <th>Norm:</th>                <td>HuberT</td>      <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Scale Est.:</th>            <td>mad</td>       <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Cov Type:</th>              <td>H1</td>        <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Date:</th>           <td>Wed, 25 May 2016</td> <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>Time:</th>               <td>15:31:16</td>     <th>                     </th>    <td> </td>  
</tr>
<tr>
  <th>No. Iterations:</th>        <td>23</td>        <th>                     </th>    <td> </td>  
</tr>
</table>
<table class="simpletable">
<tr>
        <td></td>          <th>coef</th>     <th>std err</th>      <th>z</th>      <th>P>|z|</th> <th>[95.0% Conf. Int.]</th> 
</tr>
<tr>
  <th>const</th>        <td>   -3.5187</td> <td>    0.094</td> <td>  -37.622</td> <td> 0.000</td> <td>   -3.702    -3.335</td>
</tr>
<tr>
  <th>DIPLOMA_RATE</th> <td>    3.1895</td> <td>    0.107</td> <td>   29.820</td> <td> 0.000</td> <td>    2.980     3.399</td>
</tr>
</table>




```python

```
